  INSERT into patient VALUES (4441367,"Hope","F","Atkins","hope15","password","AB","Allstate","03/10/1997");
     INSERT into patient VALUES (4441365,"Jamecia","M","Moore","jmmoore5","password","A+","TeamCare","08/30/1999");
   INSERT into patient VALUES (4441366,"Clark","M","Kent","clark","password","O","None","04/18/1938");  
