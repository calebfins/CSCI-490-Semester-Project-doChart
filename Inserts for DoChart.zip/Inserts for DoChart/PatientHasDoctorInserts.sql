INSERT into patient_has_doctor VALUES (4441367,22210087);
	INSERT into patient_has_doctor VALUES (4441367,22210085);
   INSERT into patient_has_doctor VALUES (4441365,22210086);
  INSERT into patient_has_doctor VALUES (4441365,22210087);
     
INSERT into patient_has_doctor VALUES (4441366,22210087);