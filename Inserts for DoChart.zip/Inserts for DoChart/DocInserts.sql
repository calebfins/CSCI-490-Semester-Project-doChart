INSERT into doctor VALUES (22210085,"Samuel","P","Miller","sam","password","Obstetrician");
INSERT into doctor VALUES (22210086,"Rachel","A","Porter","rachel","pass","Allergists");
INSERT into doctor VALUES (22210087,"Liam","W","Daniel","liam","pass","General Practitioner/General Physician");