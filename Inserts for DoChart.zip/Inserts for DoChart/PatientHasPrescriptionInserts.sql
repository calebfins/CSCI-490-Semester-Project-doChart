INSERT INTO patient_has_prescription values (4441365,2315963);
INSERT INTO patient_has_prescription values (4441365,740861);

INSERT INTO patient_has_prescription values (4441367,2268426);

INSERT INTO patient_has_prescription values (4441366,723770);
INSERT INTO patient_has_prescription values (4441366,2238645);
INSERT INTO patient_has_prescription values (4441366,2324253);
INSERT INTO patient_has_prescription values (4441366,2315963);
